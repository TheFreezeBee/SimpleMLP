# SimpleMLP
A simple/basic/test ;)
